package com.cg.marriageceremony.exceptions;

public class CatererDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CatererDoesNotExistException() {
		// TODO Auto-generated constructor stub
	}

	public CatererDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
