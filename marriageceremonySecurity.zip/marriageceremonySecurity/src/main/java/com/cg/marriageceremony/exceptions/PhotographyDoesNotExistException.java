package com.cg.marriageceremony.exceptions;

public class PhotographyDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PhotographyDoesNotExistException() {
		// TODO Auto-generated constructor stub
	}

	public PhotographyDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PhotographyDoesNotExistException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PhotographyDoesNotExistException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PhotographyDoesNotExistException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
