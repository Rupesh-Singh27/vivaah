package com.cg.marriageceremony.exceptions;

public class VendorDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VendorDoesNotExistException() {
		// TODO Auto-generated constructor stub
	}

	public VendorDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
