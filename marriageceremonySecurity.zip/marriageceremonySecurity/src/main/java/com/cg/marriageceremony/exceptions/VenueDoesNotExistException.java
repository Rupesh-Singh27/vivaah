package com.cg.marriageceremony.exceptions;

public class VenueDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VenueDoesNotExistException() {
		// TODO Auto-generated constructor stub
	}

	public VenueDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
