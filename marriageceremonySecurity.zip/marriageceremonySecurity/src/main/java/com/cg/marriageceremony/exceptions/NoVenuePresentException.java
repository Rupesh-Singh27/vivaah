package com.cg.marriageceremony.exceptions;

public class NoVenuePresentException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoVenuePresentException() {
		// TODO Auto-generated constructor stub
	}
	
	public NoVenuePresentException(String message) {
		super(message);
	}

}
