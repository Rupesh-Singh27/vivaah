package com.cg.marriageceremony.exceptions;

public class PaymentDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PaymentDoesNotExistException() {
		// TODO Auto-generated constructor stub
	}

	public PaymentDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
