package com.cg.marriageceremony.exceptions;

public class MarriageCeremonyApplicationException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MarriageCeremonyApplicationException() {

	}

	public MarriageCeremonyApplicationException(String msg) {
		super(msg);

	}
}
