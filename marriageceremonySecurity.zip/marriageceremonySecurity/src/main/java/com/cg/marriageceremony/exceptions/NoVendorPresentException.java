package com.cg.marriageceremony.exceptions;

public class NoVendorPresentException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoVendorPresentException() {
		// TODO Auto-generated constructor stub
	}

	public NoVendorPresentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
