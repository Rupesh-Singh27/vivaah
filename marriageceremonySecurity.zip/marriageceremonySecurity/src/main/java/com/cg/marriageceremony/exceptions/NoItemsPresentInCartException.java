package com.cg.marriageceremony.exceptions;

public class NoItemsPresentInCartException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoItemsPresentInCartException() {
		// TODO Auto-generated constructor stub
	}

	public NoItemsPresentInCartException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
