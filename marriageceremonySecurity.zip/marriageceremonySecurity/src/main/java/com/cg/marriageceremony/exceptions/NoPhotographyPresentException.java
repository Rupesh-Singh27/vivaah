package com.cg.marriageceremony.exceptions;

public class NoPhotographyPresentException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoPhotographyPresentException() {
		// TODO Auto-generated constructor stub
	}

	public NoPhotographyPresentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
