package com.cg.marriageceremony.exceptions;

public class FieldCannotBeEmptyExceptionForVendor extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FieldCannotBeEmptyExceptionForVendor() {
		// TODO Auto-generated constructor stub
	}

	public FieldCannotBeEmptyExceptionForVendor(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FieldCannotBeEmptyExceptionForVendor(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
