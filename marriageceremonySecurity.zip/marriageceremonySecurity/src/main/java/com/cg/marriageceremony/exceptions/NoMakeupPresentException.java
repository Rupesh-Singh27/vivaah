package com.cg.marriageceremony.exceptions;

public class NoMakeupPresentException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoMakeupPresentException() {
		// TODO Auto-generated constructor stub
	}

	public NoMakeupPresentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
