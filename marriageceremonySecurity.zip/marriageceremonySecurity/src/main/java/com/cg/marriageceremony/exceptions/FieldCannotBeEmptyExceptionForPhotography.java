package com.cg.marriageceremony.exceptions;

public class FieldCannotBeEmptyExceptionForPhotography extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FieldCannotBeEmptyExceptionForPhotography() {
		// TODO Auto-generated constructor stub
	}

	public FieldCannotBeEmptyExceptionForPhotography(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
