package com.cg.marriageceremony.exceptions;

public class FieldCannotBeEmptyExceptionForMakeup extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FieldCannotBeEmptyExceptionForMakeup() {
		// TODO Auto-generated constructor stub
	}

	public FieldCannotBeEmptyExceptionForMakeup(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
