package com.cg.marriageceremony.exceptions;

public class MakeupDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MakeupDoesNotExistException() {
		// TODO Auto-generated constructor stub
	}

	public MakeupDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
