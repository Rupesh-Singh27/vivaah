package com.cg.marriageceremony.exceptions;

public class FieldCannotBeEmptyExceptionForVenue extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FieldCannotBeEmptyExceptionForVenue() {
		// TODO Auto-generated constructor stub
	}

	public FieldCannotBeEmptyExceptionForVenue(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
