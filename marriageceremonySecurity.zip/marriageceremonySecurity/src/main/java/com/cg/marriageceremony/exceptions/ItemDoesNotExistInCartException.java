package com.cg.marriageceremony.exceptions;

public class ItemDoesNotExistInCartException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ItemDoesNotExistInCartException() {
		// TODO Auto-generated constructor stub
	}

	public ItemDoesNotExistInCartException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
